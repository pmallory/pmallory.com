Description:
  This script draws song information about what iTunes is playing onto an
  image and then uploads it to a web server to be used as a forum avatar.
  It runs indefinitely, checking every minute to see if the image needs to
  be redrawn and reuploaded. It uses iMagine Photo to draw with, so you
  should go get that from http://www.yvs.eu.com/downloading.html

Configuration instructions:
   1. Change value of variable filePath to the path of the directory that
	contains the avatar image you want to draw on.
   2. Change value of variable baseImage to the name of the image you want
	to draw on. PNGs, JPGs, TIFF should all work.
   3. Change value of variable outputImage to what you want your modified
	avatar to be saved as. This file will be overwritten overtime an
	updated avatar is generated.
   4. Change value of variable avatarWidthInCharcters to the approximate
	width of your base image in characters. Note that the text drawn on
	your avatar doesn't use a fixed width font. Be conservative.
   5. Change value of variable uploadDestination to match the username,
	server and destination path of your upload location. This will be
	fed to scp as written. You can use what's there as an example. Note,
	Make sure you've set up public key authentication so that scp
	doesn't hang on a password prompt.
   6. Download iMagine Photo (freeware) from:
	http://www.yvs.eu.com/downloading.html

Setup suggestions:
  You can put this script, the base image and iMagine Photo all in one
  hidden directory to keep things neat. Follow these instructions:
  http://www.macosxtips.co.uk/index_files/disable-the-dock-icon-for-any-application.html
  if you don't want iMagine Photo and the script to show up on your dock
  To have the script run automatically on login you can save it as an
  application and put it in your startup items.

License:
    Copyright 2010 Philip Mallory
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.