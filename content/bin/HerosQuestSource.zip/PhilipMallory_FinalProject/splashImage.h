
//{{BLOCK(splashImage)

//======================================================================
//
//	splashImage, 240x160@16, 
//	+ bitmap not compressed
//	Total size: 76800 = 76800
//
//	Time-stamp: 2010-11-07, 17:14:02
//	Exported by Cearn's GBA Image Transmogrifier
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef __SPLASHIMAGE__
#define __SPLASHIMAGE__

#define splashImageBitmapLen 76800
extern const unsigned short splashImageBitmap[38400];

#endif // __SPLASHIMAGE__

//}}BLOCK(splashImage)
