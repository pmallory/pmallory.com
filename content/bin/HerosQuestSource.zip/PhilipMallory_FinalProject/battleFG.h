
//{{BLOCK(battleFG)

//======================================================================
//
//	battleFG, 256x256@8, 
//	+ palette 256 entries, not compressed
//	+ 34 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 2176 + 2048 = 4736
//
//	Time-stamp: 2010-12-05, 14:00:58
//	Exported by Cearn's GBA Image Transmogrifier
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef __BATTLEFG__
#define __BATTLEFG__

#define battleFGTilesLen 2176
extern const unsigned short battleFGTiles[1088];

#define battleFGMapLen 2048
extern const unsigned short battleFGMap[1024];

#define battleFGPalLen 512
extern const unsigned short battleFGPal[256];

#endif // __BATTLEFG__

//}}BLOCK(battleFG)
