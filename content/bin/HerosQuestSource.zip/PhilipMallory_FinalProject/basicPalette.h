
//{{BLOCK(basicPalette)

//======================================================================
//
//	basicPalette, 240x160@8, 
//	+ palette 256 entries, not compressed
//	+ 600 tiles not compressed
//	Total size: 512 + 38400 = 38912
//
//	Time-stamp: 2010-11-07, 16:12:38
//	Exported by Cearn's GBA Image Transmogrifier
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef __BASICPALETTE__
#define __BASICPALETTE__

#define basicPalettePalLen 512
extern const unsigned short basicPalettePal[256];

#endif // __BASICPALETTE__

//}}BLOCK(basicPalette)
