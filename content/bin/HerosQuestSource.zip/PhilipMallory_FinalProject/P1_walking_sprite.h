
//{{BLOCK(P1_walking_sprite)

//======================================================================
//
//	P1_walking_sprite, 128x256@8, 
//	+ palette 256 entries, not compressed
//	+ 512 tiles not compressed
//	Total size: 512 + 32768 = 33280
//
//	Time-stamp: 2010-11-16, 21:42:59
//	Exported by Cearn's GBA Image Transmogrifier
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef __P1_WALKING_SPRITE__
#define __P1_WALKING_SPRITE__

#define P1_walking_spriteTilesLen 32768
extern const unsigned short P1_walking_spriteTiles[16384];

#define P1_walking_spritePalLen 512
extern const unsigned short P1_walking_spritePal[256];

#endif // __P1_WALKING_SPRITE__

//}}BLOCK(P1_walking_sprite)
